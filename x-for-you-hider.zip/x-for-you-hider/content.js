function hideForYouTab() {
    const forYouTab = Array.from(document.querySelectorAll('a[role="tab"]')).find(
      tab => tab.textContent.trim() === "For you"
    );
    
    if (forYouTab) {
      forYouTab.style.display = 'none';
    }
  }
  
  setTimeout(hideForYouTab, 3000);
  setTimeout(hideForYouTab, 6000);
  
  // Also run the function whenever the URL changes (for single-page apps)
  let lastUrl = location.href; 
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(hideForYouTab, 3000);
      setTimeout(hideForYouTab, 6000);
    }
  }).observe(document, {subtree: true, childList: true});